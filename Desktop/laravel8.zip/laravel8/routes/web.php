<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductCRUDController;
Route::get('/', function () {
    return view('welcome');
});
Route::resource('products', ProductCRUDController::class);
