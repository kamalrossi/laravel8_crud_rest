<?php
namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
class ProductController extends Controller
{
public function index()
{
$data['product'] = Product::orderBy('id')->paginate(5);
return view('products.index', $data);
}

public function create()
{
return view('products.create');
}



public function store(Request $request)
{
$request->validate([
'name' => 'required',
'description' => 'required',
]);
$product = new Product;
$product->name = $request->name;
$product->description = $request->description;
$product->save();
return redirect()->route('products.index')
->with('success','Product has been created successfully.');
}



public function show(Product $product)
{
return view('products.show',compact('product'));
} 




public function edit(Product $product)
{
return view('products.edit',compact('product'));
}


public function update(Request $request, $id)
{
$request->validate([
'name' => 'required',
'description' => 'required'

]);
$product = Product::find($id);
$product->name = $request->name;
$product->description = $request->description;
$product->save();
return redirect()->route('products.index')
->with('success','Product Has Been updated successfully');
}


public function destroy(Product $product)
{
$product->delete();
return redirect()->route('products.index')
->with('success','Product has been deleted successfully');
}
}